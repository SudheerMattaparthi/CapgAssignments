package com.cabapp.pro.entity;

import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

 

@Entity(name="Review")
public class Review {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	private int customerId;
	private float rating;
	private String comment;
	
	@ManyToOne(cascade = CascadeType.ALL)
	private Customer cutomer;
	
	@ManyToOne(cascade = CascadeType.ALL)
	private Driver driver;

	public Review() {
		super();
		// TODO Auto-generated constructor stub
	}

	 

	public Review(Integer id, int customerId, float rating, String comment, Customer cutomer, Driver driver) {
		super();
		this.id = id;
		this.customerId = customerId;
		this.rating = rating;
		this.comment = comment;
		this.cutomer = cutomer;
		this.driver = driver;
	}



	public int getCustomerId() {
		return customerId;
	}



	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}



	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Customer getCutomer() {
		return cutomer;
	}

	public void setCutomer(Customer cutomer) {
		this.cutomer = cutomer;
	}

	public Driver getDriver() {
		return driver;
	}

	public void setDriver(Driver driver) {
		this.driver = driver;
	}



	@Override
	public int hashCode() {
		return Objects.hash(comment, customerId, cutomer, driver, id, rating);
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Review other = (Review) obj;
		return Objects.equals(comment, other.comment) && customerId == other.customerId
				&& Objects.equals(cutomer, other.cutomer) && Objects.equals(driver, other.driver)
				&& Objects.equals(id, other.id) && Float.floatToIntBits(rating) == Float.floatToIntBits(other.rating);
	}



	@Override
	public String toString() {
		return "Review [id=" + id + ", customerId=" + customerId + ", rating=" + rating + ", comment=" + comment
				+ ", cutomer=" + cutomer + ", driver=" + driver + "]";
	}

	 
	
	 
}
