package com.cabapp.pro.entity;

    import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.persistence.*;

import io.swagger.annotations.ApiModel;
import lombok.*;

    @Entity
   
    @ApiModel(description = "Details about Complaint Bean")
    public class Complaint {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Integer complaintId;
        private Instant dateOnRegister;
        private String comment;
        private String status;
        private String email;
        private int driverId;
        private int customerId;
    

    	@ManyToOne(cascade = CascadeType.ALL)
        private Customer customer;

    	@ManyToOne(cascade = CascadeType.ALL)
        private Driver driver;
    	
    	
    	public Complaint() {
			super();
			// TODO Auto-generated constructor stub
		}
        
     

		public Complaint(Integer complaintId, Instant dateOnRegister, String comment, String status, String email,
				int driverId, int customerId, Customer customer, Driver driver) {
			super();
			this.complaintId = complaintId;
			this.dateOnRegister = dateOnRegister;
			this.comment = comment;
			this.status = status;
			this.email = email;
			this.driverId = driverId;
			this.customerId = customerId;
			this.customer = customer;
			this.driver = driver;
		}







		public Integer getComplaintId() {
			return complaintId;
		}



		public void setComplaintId(Integer complaintId) {
			this.complaintId = complaintId;
		}



		public Instant getDateOnRegister() {
			return dateOnRegister;
		}



		public void setDateOnRegister(Instant dateOnRegister) {
			this.dateOnRegister = dateOnRegister;
		}



		public String getComment() {
			return comment;
		}



		public void setComment(String comment) {
			this.comment = comment;
		}



		public String getStatus() {
			return status;
		}



		public void setStatus(String status) {
			this.status = status;
		}



		public String getEmail() {
			return email;
		}



		public void setEmail(String email) {
			this.email = email;
		}



		public int getDriverId() {
			return driverId;
		}



		public void setDriverId(int driverId) {
			this.driverId = driverId;
		}



		public Customer getCustomer() {
			return customer;
		}



		public void setCustomer(Customer customer) {
			this.customer = customer;
		}

		
		


		public int getCustomerId() {
			return customerId;
		}



		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}



		public Driver getDriver() {
			return driver;
		}



		public void setDriver(Driver driver) {
			this.driver = driver;
		}



		@Override
		public int hashCode() {
			return Objects.hash(comment, complaintId, customer, dateOnRegister, driver, driverId, email, status);
		}



		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Complaint other = (Complaint) obj;
			return Objects.equals(comment, other.comment) && Objects.equals(complaintId, other.complaintId)
					&& Objects.equals(customer, other.customer) && Objects.equals(dateOnRegister, other.dateOnRegister)
					&& Objects.equals(driver, other.driver) && driverId == other.driverId
					&& Objects.equals(email, other.email) && Objects.equals(status, other.status);
		}



		@Override
		public String toString() {
			return "Complaint [complaintId=" + complaintId + ", dateOnRegister=" + dateOnRegister + ", comment="
					+ comment + ", status=" + status + ", email=" + email + ", driverId=" + driverId + ", customer="
					+ customer + ", driver=" + driver + "]";
		}
		
		
		
        
		 
    }
