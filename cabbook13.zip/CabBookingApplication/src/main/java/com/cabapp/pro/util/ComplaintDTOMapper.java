package com.cabapp.pro.util;

 
import com.cabapp.pro.dto.ComplaintRequestDto;
import com.cabapp.pro.dto.ComplaintResponseDTO;
import com.cabapp.pro.entity.Complaint;

public class ComplaintDTOMapper {
	public Complaint getComplaintFromComplaintDTO(ComplaintRequestDto dto)
	{
		Complaint e = new Complaint();
		
		e.setComment(dto.getComment());
		e.setCustomerId(dto.getCustomerId());
		e.setDriverId(dto.getDriverId());
		e.setEmail(dto.getEmail());
		 
		return e;
	 
		
	}
	public ComplaintResponseDTO getComplaintDTOFromComplaint(Complaint complaint) {
		ComplaintResponseDTO adto = new ComplaintResponseDTO();
	 
		adto.setComment(complaint.getComment());
		adto.setDateOnRegister(complaint.getDateOnRegister());
		 
		return adto;
	}
 

}
